//
// Created by ant1k on 18.3.18.
//

#pragma once

enum class LogicalOperation {
    And,
    Or
};
