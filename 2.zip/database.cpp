//
// Created by ant1k on 16.3.18.
//

#include "database.h"


void Database::Add(const Date &date, const std::string &event) {
    auto dateAvailability = binary_search(databaseA.begin(), databaseA.end(), date);
    if (!dateAvailability) {
        database[date].push_back(event);
        databaseA[date].insert(event);
    } else {
        auto eventAvailability = binary_search(databaseA[date].begin(),
                                               databaseA[date].end(),
                                               event);
        if (!eventAvailability) {
            database.at(date).push_back(event);
            databaseA.at(date).insert(event);
        }

    }
}

void Database::Print(std::ostream &cout) {
    for (const auto &i : database) {
        for (const auto &j : i.second) {
            cout << i.first << j << endl;
        }
    }
}


std::string Database::RemoveIf(const std::function<bool(const Date &, const std::string &)> &predicate) {
    int quantity = 0;
    std::string empty;
    if (!database.empty()) {
        for (auto &i : database) {
            for (auto &j : i.second) {
                if (predicate(i.first, j)) {
                    auto It = find(i.second.begin(), i.second.end(), j);
                    database.at(i.first).erase(It);
                    databaseA.at(i.first).erase(j);
                    ++quantity;
                }
            }
            if (database.at(i.first).empty()) {
                database.erase(i.first);
                databaseA.erase(i.first);
            };
        }
    }
    return to_string(quantity);
}


std::multimap<Date, std::string>
Database::FindIf(const std::function<bool(const Date &, const std::string &)> &predicate) {
    std::multimap<Date, std::string> quantity;
    if (!database.empty()) {
        for (auto &i : database) {
            for (auto &j : i.second) {
                if (predicate(i.first, j)) {
                    quantity.insert(make_pair(i.first, j));
                }
            }

        }
    }
    return quantity;
}


std::string Database::Last(const Date &date) {
    std::string DateEvent;
    std::ostringstream lastDate;
    if (date < ((*databaseA.begin()).first) || databaseA.empty()) {
        throw invalid_argument(lastDate.str());
    }
        auto date_range = lower_bound(databaseA.begin(), databaseA.end(), date);
        auto needDate = --date_range;
        lastDate << (*needDate).first << database.at((*needDate).first).back();
    DateEvent = lastDate.str();
    return DateEvent;
}


std::ostream &operator<<(std::ostream &stream, const std::map<Date, std::vector<std::string>> &map) {
    for (const auto &i : map) {
        for (const auto &j : i.second) {
            stream << i.first << j;
        }
    }
    return stream;
}

std::ostream &operator<<(std::ostream &stream, const std::pair<Date, std::string> &map) {
    stream << map.first << map.second;
    return stream;
}

void TestAddDateEvent() {
    {
        Database db;
        std::map<Date, std::vector<std::string>> test1;
        test1[{1985, 10, 28}].emplace_back("My dr");
        db.Add({1985, 10, 28}, "My dr");
        JUnit::AssertEqual(test1, db.database, "Test #1");
        JUnit::Assert((!db.database.empty()), "Test #1.1");
        JUnit::Assert((db.database.size() == 1), "Test #1.2");
        JUnit::Assert((db.database.size() < 2), "Test #1.3");
        JUnit::Assert(!db.database.at({1985, 10, 28}).empty(), "Test #1.4");
        JUnit::Assert(db.database.at({1985, 10, 28}).size() == 1, "Test #1.5");
        JUnit::Assert(db.database.at({1985, 10, 28}).size() < 2, "Test #1.6");
        db.Add({1985, 10, 28}, "My dr");
        JUnit::AssertEqual(test1, db.database, "Test #2");
        db.Add({1985, 10, 28}, "My dr");
        JUnit::AssertEqual(test1, db.database, "Test #3");
        test1[{1985, 10, 28}].emplace_back("My Day");
        db.Add({1985, 10, 28}, "My dr");
        db.Add({1985, 10, 28}, "My Day");
        db.Add({1985, 10, 28}, "My Day");
        db.Add({1985, 10, 28}, "My Day");
        JUnit::AssertEqual(test1, db.database, "Test #4");
    }


}
